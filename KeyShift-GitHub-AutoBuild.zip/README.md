# KeyShift ZIP auto-build workflow

Place the Android project ZIP in your GitHub repository root (or one folder below it), commit it along with `.github/workflows/build-apk.yml`, and push. Actions extracts the ZIP on its runner, finds `settings.gradle` or `settings.gradle.kts`, builds with Gradle, and uploads the debug APK as `KeyShift-debug-apk`.

The archive must contain the project root, including Gradle settings and the `app/` directory. The workflow extracts on GitHub's runner, not on your phone.
