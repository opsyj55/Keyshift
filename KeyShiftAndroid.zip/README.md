# KeyShift Android

Experimental Android app for live playback capture and semitone controls, plus an architectural starting point for an in-app player fallback.

## Requirements
- Android Studio Ladybug or newer
- JDK 17
- Android 10+ device (API 29+) for Android Playback Capture

## Open/build
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
Or run `gradle --no-daemon assembleDebug` with Gradle 8.9 and JDK 17. The project uses Kotlin 2.0.21 with the matching Compose compiler Gradle plugin. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions
Push this project to a GitHub repository. The workflow `.github/workflows/build-apk.yml` builds on push and uploads `KeyShift-debug-apk` under Actions > workflow run > Artifacts.

## Honest audio limitations
Android playback capture requires user consent and only captures eligible audio from source apps that allow capture. DRM or capture policy may block it. This starter uses linear PCM resampling to change pitch; this also changes tempo and is not a high-quality pitch-shifter. A production release should replace `LiveCapture`'s resampling loop with a tested SoundTouch/WSOLA or phase-vocoder DSP implementation, add foreground-service lifecycle handling, device testing, audio focus, robust routing, and an actual local-file player DSP pipeline. Audio capture can also be delayed and the source app may be silent/continue playing depending on device routing.

This project intentionally does not claim universal capture of Spotify/YouTube/other apps.
