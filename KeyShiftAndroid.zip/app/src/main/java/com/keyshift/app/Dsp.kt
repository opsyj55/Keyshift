package com.keyshift.app

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.sqrt

/** Streaming stereo pitch shifter. Input/output are interleaved 16-bit PCM. */
interface PitchEngine {
    fun setSemitones(value: Int)
    /** Clears all internal state (used when leaving/entering bypass). */
    fun reset()
    /** Returns interleaved stereo samples; may be empty while the engine is filling up. */
    fun process(input: ShortArray, length: Int): ShortArray
}

private fun toFloat(s: Short): Float = s / 32768f
private fun toShort(f: Float): Short = (f.coerceIn(-1f, 1f) * 32767f).roundToInt().toShort()

/**
 * Time-domain pitch shifter: WSOLA time-stretch by the pitch ratio, then cubic resampling
 * back to the original duration. Both channels share one splice point (found on the mono mix)
 * so the stereo image stays intact. Because it works on the waveform instead of rebuilding
 * a spectrum, vocals keep their natural formants and attacks stay tighter than a vocoder.
 */
class WsolaPitchShifter(semitones: Int = 0) : PitchEngine {
    private val n = 2048              // analysis/synthesis window
    private val hs = n / 2            // synthesis hop (50% overlap, periodic Hann sums to 1)
    private val tol = 640             // +/- search range for the best splice (~14.5 ms)
    private val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / n)).toFloat() }

    @Volatile private var ratio = 2.0.pow(semitones.coerceIn(-12, 12) / 12.0)

    // input history (absolute index of inL[0] is `base`)
    private var inL = FloatArray(n * 8)
    private var inR = FloatArray(n * 8)
    private var inM = FloatArray(n * 8)
    private var inLen = 0
    private var base = 0L
    private var nominal = 0.0
    private var prevPos = -1L

    // overlap-add accumulator
    private val accL = FloatArray(n)
    private val accR = FloatArray(n)

    // stretched stream waiting for the resampler
    private var stL = FloatArray(n * 8)
    private var stR = FloatArray(n * 8)
    private var stLen = 0
    private var q = 1.0

    override fun setSemitones(value: Int) { ratio = 2.0.pow(value.coerceIn(-12, 12) / 12.0) }

    override fun reset() {
        inLen = 0; base = 0L; nominal = 0.0; prevPos = -1L
        accL.fill(0f); accR.fill(0f)
        stLen = 0; q = 1.0
    }

    override fun process(input: ShortArray, length: Int): ShortArray {
        val frames = length / 2
        if (frames <= 0) return ShortArray(0)
        appendInput(input, frames)
        runWsola()
        return resample()
    }

    private fun appendInput(input: ShortArray, frames: Int) {
        if (inLen + frames > inL.size) {
            val cap = max(inL.size * 2, inLen + frames)
            inL = inL.copyOf(cap); inR = inR.copyOf(cap); inM = inM.copyOf(cap)
        }
        for (i in 0 until frames) {
            val l = toFloat(input[i * 2])
            val r = toFloat(input[i * 2 + 1])
            inL[inLen + i] = l; inR[inLen + i] = r; inM[inLen + i] = 0.5f * (l + r)
        }
        inLen += frames
    }

    private fun runWsola() {
        val ha = hs / ratio
        while (true) {
            val end = base + inLen
            val nom = nominal.roundToLong()
            val pos: Long
            if (prevPos < 0) {
                if (end < n) break
                pos = 0L
            } else {
                if (end < nom + tol + n) break
                pos = bestSplice(nom)
            }
            val a = (pos - base).toInt()
            for (i in 0 until n) {
                accL[i] += inL[a + i] * win[i]
                accR[i] += inR[a + i] * win[i]
            }
            appendStretched()
            accL.copyInto(accL, 0, hs, n); accL.fill(0f, hs, n)
            accR.copyInto(accR, 0, hs, n); accR.fill(0f, hs, n)
            prevPos = pos
            nominal += ha
            trimInput(pos)
        }
    }

    /** Picks the candidate near `nom` whose start best continues the previous frame. */
    private fun bestSplice(nom: Long): Long {
        val tgt = (prevPos + hs - base).toInt()
        var tE = 0f
        run { var i = 0; while (i < hs) { val b = inM[tgt + i]; tE += b * b; i += 2 } }
        val lo = max(nom - tol, 0L)
        val hi = nom + tol
        var best = -Float.MAX_VALUE
        var bestPos = nom
        var c = lo
        while (c <= hi) {
            val s = score((c - base).toInt(), tgt, tE)
            if (s > best) { best = s; bestPos = c }
            c += 2
        }
        for (d in longArrayOf(-1L, 1L)) {
            val cc = bestPos + d
            if (cc < lo || cc > hi) continue
            val s = score((cc - base).toInt(), tgt, tE)
            if (s > best) { best = s; bestPos = cc }
        }
        return bestPos
    }

    private fun score(cand: Int, tgt: Int, tE: Float): Float {
        var num = 0f; var e = 0f
        var i = 0
        while (i < hs) {
            val a = inM[cand + i]
            num += a * inM[tgt + i]
            e += a * a
            i += 2
        }
        return num / (sqrt(e * tE) + 1e-6f)
    }

    private fun trimInput(pos: Long) {
        val keep = max(min(pos + hs, nominal.roundToLong() - tol), base)
        val cut = (keep - base).toInt()
        if (cut > 0) {
            inL.copyInto(inL, 0, cut, inLen)
            inR.copyInto(inR, 0, cut, inLen)
            inM.copyInto(inM, 0, cut, inLen)
            inLen -= cut
            base = keep
        }
    }

    private fun appendStretched() {
        if (stLen + hs > stL.size) {
            val cap = max(stL.size * 2, stLen + hs)
            stL = stL.copyOf(cap); stR = stR.copyOf(cap)
        }
        accL.copyInto(stL, stLen, 0, hs)
        accR.copyInto(stR, stLen, 0, hs)
        stLen += hs
    }

    /** Reads the stretched stream `ratio` samples per output sample (4-point cubic). */
    private fun resample(): ShortArray {
        val step = ratio
        val maxOut = ((stLen - q) / step).toInt() + 2
        if (maxOut <= 0) return ShortArray(0)
        val out = ShortArray(maxOut * 2)
        var count = 0
        var pos = q
        while (true) {
            val i = floor(pos).toInt()
            if (i + 2 >= stLen) break
            val f = (pos - i).toFloat()
            out[count * 2] = toShort(cubic(stL, i, f))
            out[count * 2 + 1] = toShort(cubic(stR, i, f))
            count++
            pos += step
            if (count >= maxOut) break
        }
        val drop = max(floor(pos).toInt() - 1, 0)
        if (drop > 0) {
            stL.copyInto(stL, 0, drop, stLen)
            stR.copyInto(stR, 0, drop, stLen)
            stLen -= drop
            pos -= drop
        }
        q = pos
        return if (count * 2 == out.size) out else out.copyOf(count * 2)
    }

    private fun cubic(s: FloatArray, i: Int, f: Float): Float {
        val y0 = s[i - 1]; val y1 = s[i]; val y2 = s[i + 1]; val y3 = s[i + 2]
        return y1 + 0.5f * f * (y2 - y0 + f * (2f * y0 - 5f * y1 + 4f * y2 - y3 + f * (3f * (y1 - y2) + y3 - y0)))
    }
}

/**
 * The original phase-vocoder engine, kept as the "Smooth" option. Algorithm unchanged;
 * only the allocations were removed (window, work arrays and output are reused).
 */
class StereoPhaseVocoder(semitones: Int = 0) : PitchEngine {
    private val left = PhaseVocoderChannel(semitones)
    private val right = PhaseVocoderChannel(semitones)

    override fun setSemitones(value: Int) { left.setSemitones(value); right.setSemitones(value) }
    override fun reset() { left.reset(); right.reset() }

    override fun process(input: ShortArray, length: Int): ShortArray {
        val frames = length / 2
        if (frames <= 0) return ShortArray(0)
        val lIn = FloatArray(frames)
        val rIn = FloatArray(frames)
        for (i in 0 until frames) {
            lIn[i] = toFloat(input[i * 2])
            rIn[i] = toFloat(input[i * 2 + 1])
        }
        val lOut = left.process(lIn)
        val rOut = right.process(rIn)
        val count = min(lOut.size, rOut.size)
        val out = ShortArray(count * 2)
        for (i in 0 until count) {
            out[i * 2] = toShort(lOut[i])
            out[i * 2 + 1] = toShort(rOut[i])
        }
        return out
    }
}

private class PhaseVocoderChannel(initialSemitones: Int) {
    private val size = 2048
    private val hop = 512
    private val half = size / 2
    private var semitones = initialSemitones.coerceIn(-12, 12)
    @Volatile private var ratio = 2.0.pow(semitones / 12.0)
    private var input = FloatArray(size * 2)
    private var inputCount = 0
    private val overlap = FloatArray(size)
    private val norm = FloatArray(size)
    private val previousPhase = DoubleArray(half + 1)
    private val synthesisPhase = DoubleArray(half + 1)
    private var initialized = false

    private val window = DoubleArray(size) { 0.5 - 0.5 * cos(2.0 * PI * it / (size - 1)) }
    private val real = DoubleArray(size)
    private val imag = DoubleArray(size)
    private val mag = DoubleArray(half + 1)
    private val phase = DoubleArray(half + 1)
    private val outReal = DoubleArray(size)
    private val outImag = DoubleArray(size)

    fun setSemitones(value: Int) {
        val v = value.coerceIn(-12, 12)
        if (v != semitones) { semitones = v; ratio = 2.0.pow(v / 12.0) }
    }

    fun reset() {
        inputCount = 0
        overlap.fill(0f); norm.fill(0f)
        previousPhase.fill(0.0); synthesisPhase.fill(0.0)
        initialized = false
    }

    fun process(samples: FloatArray): FloatArray {
        if (inputCount + samples.size > input.size) input = input.copyOf(max(inputCount + samples.size, input.size * 2))
        samples.copyInto(input, inputCount)
        inputCount += samples.size
        val nFrames = if (inputCount >= size) (inputCount - size) / hop + 1 else 0
        val result = FloatArray(nFrames * hop)
        for (f in 0 until nFrames) {
            processFrame()
            for (i in 0 until hop) result[f * hop + i] = if (norm[i] > 1e-8f) overlap[i] / norm[i] else 0f
            overlap.copyInto(overlap, 0, hop, size)
            norm.copyInto(norm, 0, hop, size)
            for (i in size - hop until size) { overlap[i] = 0f; norm[i] = 0f }
            input.copyInto(input, 0, hop, inputCount)
            inputCount -= hop
        }
        return result
    }

    private fun processFrame() {
        val ratio = this.ratio
        for (i in 0 until size) { real[i] = input[i] * window[i]; imag[i] = 0.0 }
        fft(real, imag, false)
        for (k in 0..half) {
            mag[k] = hypot(real[k], imag[k])
            phase[k] = atan2(imag[k], real[k])
        }
        for (k in 0..half) {
            val src = (k / ratio).coerceIn(0.0, half.toDouble())
            val lo = src.toInt()
            val hi = min(lo + 1, half)
            val frac = src - lo
            val amplitude = mag[lo] * (1.0 - frac) + mag[hi] * frac
            val sourceBin = src.roundToInt().coerceIn(0, half)
            val inputPhase = phase[sourceBin]
            val expected = 2.0 * PI * sourceBin * hop / size
            if (!initialized) synthesisPhase[k] = inputPhase * ratio
            else {
                val delta = wrap(inputPhase - previousPhase[sourceBin] - expected)
                synthesisPhase[k] += (expected + delta) * ratio
            }
            outReal[k] = amplitude * cos(synthesisPhase[k])
            outImag[k] = amplitude * sin(synthesisPhase[k])
        }
        for (k in 1 until half) {
            outReal[size - k] = outReal[k]
            outImag[size - k] = -outImag[k]
        }
        fft(outReal, outImag, true)
        for (i in 0 until size) {
            val w = window[i]
            overlap[i] += (outReal[i] * w).toFloat()
            norm[i] += (w * w).toFloat()
        }
        for (k in 0..half) previousPhase[k] = phase[k]
        initialized = true
    }

    private fun wrap(value: Double): Double {
        var x = value
        while (x > PI) x -= 2.0 * PI
        while (x < -PI) x += 2.0 * PI
        return x
    }

    private fun fft(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        val len = re.size
        var j = 0
        for (i in 1 until len) {
            var bit = len shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var m = 2
        while (m <= len) {
            val angle = 2.0 * PI / m * if (inverse) 1.0 else -1.0
            val wLenR = cos(angle)
            val wLenI = sin(angle)
            var start = 0
            while (start < len) {
                var wr = 1.0; var wi = 0.0
                for (k in 0 until m / 2) {
                    val even = start + k
                    val odd = even + m / 2
                    val tr = wr * re[odd] - wi * im[odd]
                    val ti = wr * im[odd] + wi * re[odd]
                    re[odd] = re[even] - tr
                    im[odd] = im[even] - ti
                    re[even] += tr
                    im[even] += ti
                    val nextWr = wr * wLenR - wi * wLenI
                    wi = wr * wLenI + wi * wLenR
                    wr = nextWr
                }
                start += m
            }
            m = m shl 1
        }
        if (inverse) for (i in 0 until len) { re[i] /= len; im[i] /= len }
    }
}
