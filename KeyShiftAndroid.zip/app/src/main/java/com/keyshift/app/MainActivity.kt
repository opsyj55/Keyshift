package com.keyshift.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private var capture: LiveCapture? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var semitones by remember { mutableIntStateOf(0) }
                var active by remember { mutableStateOf(false) }
                var status by remember { mutableStateOf("Ready. Start another app's music first.") }
                val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                    if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                        try {
                            val projection = projectionManager.getMediaProjection(result.resultCode, result.data!!)
                            capture?.stop()
                            capture = LiveCapture(projection, semitones) { msg -> runOnUiThread { status = msg } }
                            capture?.start()
                            active = true
                            status = "Capturing compatible playback. Use the + / − controls."
                        } catch (e: Exception) { status = "Could not start capture: ${e.message}" }
                    } else status = "Capture permission was not granted."
                }
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        Text("KeyShift", style = MaterialTheme.typography.headlineLarge)
                        Text("Live pitch control • experimental", color = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.height(24.dp))
                        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("PITCH SHIFT", style = MaterialTheme.typography.labelLarge)
                                Text(if (semitones > 0) "+$semitones" else "$semitones", style = MaterialTheme.typography.displayLarge)
                                Text("semitones", color = MaterialTheme.colorScheme.secondary)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                    Button(onClick = { semitones = (semitones - 1).coerceAtLeast(-12); capture?.setShift(semitones) },
                                        enabled = semitones > -12) { Text("−") }
                                    OutlinedButton(onClick = { semitones = 0; capture?.setShift(0) }) { Text("Reset") }
                                    Button(onClick = { semitones = (semitones + 1).coerceAtMost(12); capture?.setShift(semitones) },
                                        enabled = semitones < 12) { Text("+") }
                                }
                                Text("Range: −12 to +12 semitones", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Button(onClick = {
                            if (!active) {
                                status = "Approve Android's playback-capture prompt."
                                launcher.launch(projectionManager.createScreenCaptureIntent())
                            } else {
                                capture?.stop(); capture = null; active = false
                                status = "Capture stopped."
                            }
                        }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                            Text(if (active) "Stop live capture" else "Start live capture")
                        }
                        Text(status, style = MaterialTheme.typography.bodyMedium)
                        Divider()
                        Text("Compatibility", style = MaterialTheme.typography.titleMedium)
                        Text("Android 10+ playback capture only works for apps that allow capture and for eligible audio usages. DRM-protected or capture-blocked apps may produce silence. This prototype changes playback sample rate to shift pitch, so tempo also changes; it is not yet a tempo-preserving studio-quality pitch shifter. Captured audio is routed to this app's output and may not be heard in the source app simultaneously.")
                        Text("Dedicated player fallback: import/play a local track in your preferred player, then use live capture only if that player permits playback capture.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        capture?.stop()
        super.onDestroy()
    }
}

private class LiveCapture(
    private val projection: MediaProjection,
    initialShift: Int,
    private val report: (String) -> Unit
) {
    @Volatile private var shift = initialShift
    @Volatile private var running = false
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null

    fun setShift(value: Int) { shift = value.coerceIn(-12, 12) }

    fun start() {
        if (running) return
        running = true
        worker = Thread {
            try {
                val rate = 44100
                val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val config = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME)
                    .build()
                val format = AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                recorder = AudioRecord.Builder().setAudioFormat(format)
                    .setBufferSizeInBytes(maxOf(minIn, 8192)).setAudioPlaybackCaptureConfig(config).build()
                track = AudioTrack.Builder().setAudioFormat(
                    AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                ).setBufferSizeInBytes(maxOf(minOut, 8192))
                    .setTransferMode(AudioTrack.MODE_STREAM).setAudioAttributes(
                        android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build()
                    ).build()
                recorder?.startRecording()
                track?.play()
                val input = ShortArray(4096)
                while (running) {
                    val n = recorder?.read(input, 0, input.size) ?: 0
                    if (n > 0) {
                        val ratio = Math.pow(2.0, shift / 12.0)
                        val output = ShortArray(n)
                        // Simple linear resampling: shifts pitch and tempo together.
                        for (i in 0 until n) {
                            val sourceIndex = (i * ratio).roundToInt().coerceIn(0, n - 1)
                            output[i] = input[sourceIndex]
                        }
                        track?.write(output, 0, n)
                    }
                }
            } catch (e: Exception) { report("Audio capture error: ${e.message}") }
            finally { release() }
        }.apply { name = "KeyShiftCapture"; start() }
    }

    fun stop() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
        try { projection.stop() } catch (_: Exception) {}
    }

    private fun release() {
        try { recorder?.release() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        recorder = null; track = null
    }
}
