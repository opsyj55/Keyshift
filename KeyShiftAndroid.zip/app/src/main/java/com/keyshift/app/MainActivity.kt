package com.keyshift.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private val musicalKeys = listOf("C", "C♯/D♭", "D", "D♯/E♭", "E", "F", "F♯/G♭", "G", "G♯/A♭", "A", "A♯/B♭", "B")

private fun intervalBetween(from: Int, to: Int): Int {
    var d = to - from
    if (d > 6) d -= 12
    if (d < -6) d += 12
    return d
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var sourceKey by remember { mutableIntStateOf(5) } // F
                var targetKey by remember { mutableIntStateOf(0) } // C
                var active by remember { mutableStateOf(false) }
                var status by remember { mutableStateOf("Play music in a compatible app, then start capture.") }
                var sourceMenu by remember { mutableStateOf(false) }
                var targetMenu by remember { mutableStateOf(false) }
                val semitones = intervalBetween(sourceKey, targetKey)
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

                val captureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                    val data = result.data
                    if (result.resultCode == Activity.RESULT_OK && data != null) {
                        val serviceIntent = Intent(this@MainActivity, PlaybackCaptureService::class.java).apply {
                            action = PlaybackCaptureService.ACTION_START
                            putExtra(PlaybackCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                            putExtra(PlaybackCaptureService.EXTRA_RESULT_DATA, data)
                            putExtra(PlaybackCaptureService.EXTRA_SHIFT, semitones)
                        }
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                            active = true
                            status = "Capture active. Audio is transposed and played by KeyShift."
                        } catch (e: Exception) { status = "Could not start capture: ${e.message}" }
                    } else status = "Capture permission was not granted."
                }

                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        Modifier.fillMaxSize().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(15.dp)
                    ) {
                        Text("KeyShift", style = MaterialTheme.typography.headlineLarge)
                        Text("Live music transposer • experimental", color = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.height(12.dp))
                        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("TRANSPOSE MUSIC", style = MaterialTheme.typography.labelLarge)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Original key", style = MaterialTheme.typography.labelMedium)
                                        Box {
                                            OutlinedButton(onClick = { sourceMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(musicalKeys[sourceKey]) }
                                            DropdownMenu(expanded = sourceMenu, onDismissRequest = { sourceMenu = false }) {
                                                musicalKeys.forEachIndexed { i, key -> DropdownMenuItem(text = { Text(key) }, onClick = { sourceKey = i; sourceMenu = false; sendShift(intervalBetween(i, targetKey)) }) }
                                            }
                                        }
                                    }
                                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Target key", style = MaterialTheme.typography.labelMedium)
                                        Box {
                                            OutlinedButton(onClick = { targetMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(musicalKeys[targetKey]) }
                                            DropdownMenu(expanded = targetMenu, onDismissRequest = { targetMenu = false }) {
                                                musicalKeys.forEachIndexed { i, key -> DropdownMenuItem(text = { Text(key) }, onClick = { targetKey = i; targetMenu = false; sendShift(intervalBetween(sourceKey, i)) }) }
                                            }
                                        }
                                    }
                                }
                                Text(if (semitones > 0) "+$semitones semitones" else "$semitones semitones", style = MaterialTheme.typography.headlineMedium)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                    Button(onClick = {
                                        val next = (targetKey - 1 + 12) % 12
                                        targetKey = next
                                        sendShift(intervalBetween(sourceKey, next))
                                    }) { Text("−") }
                                    OutlinedButton(onClick = { targetKey = sourceKey; sendShift(0) }) { Text("Reset") }
                                    Button(onClick = {
                                        val next = (targetKey + 1) % 12
                                        targetKey = next
                                        sendShift(intervalBetween(sourceKey, next))
                                    }) { Text("+") }
                                }
                                Text("Whole mix: vocals + instruments", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Button(onClick = {
                            if (!active) captureLauncher.launch(manager.createScreenCaptureIntent())
                            else {
                                startService(Intent(this@MainActivity, PlaybackCaptureService::class.java).apply { action = PlaybackCaptureService.ACTION_STOP })
                                active = false
                                status = "Capture stopped."
                            }
                        }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                            Text(if (active) "Stop transposing" else "Start transposing")
                        }
                        Text(status, style = MaterialTheme.typography.bodyMedium)
                        HorizontalDivider()
                        Text("Compatibility & audio quality", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Captures eligible playback from apps that allow Android playback capture. Some streaming apps, DRM content, and protected audio cannot be captured. KeyShift plays the processed mix through its own audio output; the original app may also remain audible, so pause or mute it if you hear doubling. Pitch shifting is experimental and may introduce artifacts, especially at large intervals.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }

    private fun sendShift(value: Int) {
        startService(Intent(this, PlaybackCaptureService::class.java).apply {
            action = PlaybackCaptureService.ACTION_SET_SHIFT
            putExtra(PlaybackCaptureService.EXTRA_SHIFT, value.coerceIn(-12, 12))
        })
    }
}
