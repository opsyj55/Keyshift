package com.keyshift.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var semitones by remember { mutableIntStateOf(0) }
                var active by remember { mutableStateOf(false) }
                var status by remember { mutableStateOf("Ready. Start music in another app, then begin capture.") }
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

                val captureLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    val data = result.data
                    if (result.resultCode == Activity.RESULT_OK && data != null) {
                        val serviceIntent = Intent(this@MainActivity, PlaybackCaptureService::class.java).apply {
                            action = PlaybackCaptureService.ACTION_START
                            putExtra(PlaybackCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                            putExtra(PlaybackCaptureService.EXTRA_RESULT_DATA, data)
                            putExtra(PlaybackCaptureService.EXTRA_SHIFT, semitones)
                        }
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
                            else startService(serviceIntent)
                            active = true
                            status = "Capture service started. Only compatible audio apps can be captured."
                        } catch (e: Exception) {
                            status = "Could not start capture service: ${e.message}"
                        }
                    } else status = "Capture permission was not granted."
                }

                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        Modifier.fillMaxSize().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        Text("KeyShift", style = MaterialTheme.typography.headlineLarge)
                        Text("Live pitch control • experimental", color = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.height(24.dp))
                        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("PITCH SHIFT", style = MaterialTheme.typography.labelLarge)
                                Text(if (semitones > 0) "+$semitones" else "$semitones", style = MaterialTheme.typography.displayLarge)
                                Text("semitones", color = MaterialTheme.colorScheme.secondary)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                    Button(onClick = {
                                        semitones = (semitones - 1).coerceAtLeast(-12)
                                        sendShift(semitones)
                                    }, enabled = semitones > -12) { Text("−") }
                                    OutlinedButton(onClick = { semitones = 0; sendShift(0) }) { Text("Reset") }
                                    Button(onClick = {
                                        semitones = (semitones + 1).coerceAtMost(12)
                                        sendShift(semitones)
                                    }, enabled = semitones < 12) { Text("+") }
                                }
                                Text("Range: −12 to +12 semitones", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Button(onClick = {
                            if (!active) {
                                status = "Approve Android's screen/audio capture permission."
                                captureLauncher.launch(manager.createScreenCaptureIntent())
                            } else {
                                startService(Intent(this@MainActivity, PlaybackCaptureService::class.java).apply {
                                    action = PlaybackCaptureService.ACTION_STOP
                                })
                                active = false
                                status = "Capture stopped."
                            }
                        }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                            Text(if (active) "Stop live capture" else "Start live capture")
                        }
                        Text(status, style = MaterialTheme.typography.bodyMedium)
                        HorizontalDivider()
                        Text("Compatibility", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Android 10+ playback capture only works for apps that allow capture and eligible audio usages. DRM-protected or capture-blocked apps may produce silence. This prototype changes pitch by resampling, so tempo changes too. It is not yet a tempo-preserving studio-quality pitch shifter.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            "A persistent KeyShift notification appears while capture is active. Captured audio may not play through the original app's output at the same time.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    private fun sendShift(value: Int) {
        startService(Intent(this, PlaybackCaptureService::class.java).apply {
            action = PlaybackCaptureService.ACTION_SET_SHIFT
            putExtra(PlaybackCaptureService.EXTRA_SHIFT, value)
        })
    }
}
