package com.keyshift.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioPlaybackCaptureConfiguration
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import kotlin.math.roundToInt

class PlaybackCaptureService : Service() {
    @Volatile private var shift = 0
    @Volatile private var running = false
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    @Volatile private var processor: StereoPhaseVocoder? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SET_SHIFT -> {
                shift = intent.getIntExtra(EXTRA_SHIFT, shift).coerceIn(-12, 12)
                processor?.setSemitones(shift)
            }
            ACTION_STOP -> { stopCapture(); stopSelf() }
            ACTION_START -> {
                if (running) return START_NOT_STICKY
                shift = intent.getIntExtra(EXTRA_SHIFT, 0).coerceIn(-12, 12)
                startCaptureForeground()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
                if (resultData == null) { stopSelf(); return START_NOT_STICKY }
                try {
                    val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = manager.getMediaProjection(resultCode, resultData)
                    beginAudioLoop()
                } catch (_: Exception) { stopCapture(); stopSelf() }
            }
        }
        return START_NOT_STICKY
    }

    private fun startCaptureForeground() {
        val channelId = "keyshift_capture"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(channelId, "KeyShift live capture", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId).setContentTitle("KeyShift is transposing audio")
                .setContentText("Live music processing is active").setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("KeyShift is transposing audio")
                .setContentText("Live music processing is active").setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true).build()
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(FOREGROUND_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(FOREGROUND_ID, notification)
    }

    private fun beginAudioLoop() {
        running = true
        worker = Thread {
            try {
                val rate = 44100
                val inMin = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME).build()
                val inFormat = AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                recorder = AudioRecord.Builder().setAudioFormat(inFormat).setBufferSizeInBytes(maxOf(inMin, 16384))
                    .setAudioPlaybackCaptureConfig(config).build()

                val outMin = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val outFormat = AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                track = AudioTrack.Builder().setAudioFormat(outFormat).setBufferSizeInBytes(maxOf(outMin, 16384))
                    .setTransferMode(AudioTrack.MODE_STREAM).setAudioAttributes(
                        android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build()
                    ).build()

                val dsp = StereoPhaseVocoder(rate, shift)
                processor = dsp
                recorder?.startRecording()
                track?.play()
                val input = ShortArray(2048)
                while (running) {
                    val n = recorder?.read(input, 0, input.size) ?: 0
                    if (n > 0) {
                        val output = dsp.process(input, n)
                        if (output.isNotEmpty()) track?.write(output, 0, output.size)
                    } else if (n < 0) {
                        throw IllegalStateException("Audio capture read failed ($n)")
                    }
                }
            } catch (_: Exception) {
                // Capture can fail if the source app blocks playback capture or Android revokes permission.
            } finally { releaseAudio() }
        }.apply { name = "KeyShiftPhaseVocoder"; start() }
    }

    private fun stopCapture() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        releaseAudio()
        processor = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun releaseAudio() {
        try { recorder?.release() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        recorder = null; track = null
    }

    override fun onDestroy() { stopCapture(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.keyshift.app.START_CAPTURE"
        const val ACTION_STOP = "com.keyshift.app.STOP_CAPTURE"
        const val ACTION_SET_SHIFT = "com.keyshift.app.SET_SHIFT"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_SHIFT = "shift"
        private const val FOREGROUND_ID = 41
    }
}

/**
 * Streaming phase-vocoder pitch shifter. It changes spectral pitch while retaining
 * the frame cadence, so it does not intentionally change song duration/tempo.
 * This is a lightweight experimental implementation; a production-grade engine
 * should add transient handling, stereo-linking, limiter and device profiling.
 */
private class StereoPhaseVocoder(sampleRate: Int, semitones: Int) {
    private val left = PhaseVocoderChannel(semitones)
    private val right = PhaseVocoderChannel(semitones)

    fun setSemitones(value: Int) {
        left.setSemitones(value)
        right.setSemitones(value)
    }

    fun process(input: ShortArray, length: Int): ShortArray {
        val frames = length / 2
        val lIn = FloatArray(frames)
        val rIn = FloatArray(frames)
        for (i in 0 until frames) {
            lIn[i] = input[i * 2] / 32768f
            rIn[i] = input[i * 2 + 1] / 32768f
        }
        val lOut = left.process(lIn)
        val rOut = right.process(rIn)
        val count = minOf(lOut.size, rOut.size)
        val out = ShortArray(count * 2)
        for (i in 0 until count) {
            out[i * 2] = (lOut[i].coerceIn(-1f, 1f) * 32767f).roundToInt().toShort()
            out[i * 2 + 1] = (rOut[i].coerceIn(-1f, 1f) * 32767f).roundToInt().toShort()
        }
        return out
    }
}

private class PhaseVocoderChannel(initialSemitones: Int) {
    private val size = 2048
    private val hop = 512
    private val half = size / 2
    private var semitones = initialSemitones
    private var ratio = Math.pow(2.0, initialSemitones / 12.0)
    private var input = FloatArray(size * 2)
    private var inputCount = 0
    private var overlap = FloatArray(size)
    private var norm = FloatArray(size)
    private val previousPhase = DoubleArray(half + 1)
    private val synthesisPhase = DoubleArray(half + 1)
    private var initialized = false

    fun setSemitones(value: Int) {
        val v = value.coerceIn(-12, 12)
        if (v != semitones) {
            semitones = v
            ratio = Math.pow(2.0, v / 12.0)
        }
    }

    fun process(samples: FloatArray): FloatArray {
        ensureInput(inputCount + samples.size)
        samples.copyInto(input, inputCount)
        inputCount += samples.size
        val result = ArrayList<Float>()
        while (inputCount >= size) {
            processFrame()
            for (i in 0 until hop) {
                result.add(if (norm[i] > 1e-8f) overlap[i] / norm[i] else 0f)
            }
            overlap.copyInto(overlap, 0, hop, size)
            norm.copyInto(norm, 0, hop, size)
            for (i in size - hop until size) { overlap[i] = 0f; norm[i] = 0f }
            input.copyInto(input, 0, hop, inputCount)
            inputCount -= hop
        }
        return FloatArray(result.size) { result[it] }
    }

    private fun processFrame() {
        val real = DoubleArray(size)
        val imag = DoubleArray(size)
        val window = DoubleArray(size)
        for (i in 0 until size) {
            val w = 0.5 - 0.5 * kotlin.math.cos(2.0 * Math.PI * i / (size - 1))
            window[i] = w
            real[i] = input[i] * w
        }
        fft(real, imag, false)
        val mag = DoubleArray(half + 1)
        val phase = DoubleArray(half + 1)
        for (k in 0..half) {
            mag[k] = kotlin.math.hypot(real[k], imag[k])
            phase[k] = kotlin.math.atan2(imag[k], real[k])
        }

        val outReal = DoubleArray(size)
        val outImag = DoubleArray(size)
        for (k in 0..half) {
            val src = (k / ratio).coerceIn(0.0, half.toDouble())
            val lo = src.toInt()
            val hi = minOf(lo + 1, half)
            val frac = src - lo
            val amplitude = mag[lo] * (1.0 - frac) + mag[hi] * frac
            val sourceBin = src.roundToInt().coerceIn(0, half)
            val inputPhase = phase[sourceBin]
            val expected = 2.0 * Math.PI * sourceBin * hop / size
            if (!initialized) synthesisPhase[k] = inputPhase * ratio
            else {
                val delta = wrap(inputPhase - previousPhase[sourceBin] - expected)
                synthesisPhase[k] += (expected + delta) * ratio
            }
            outReal[k] = amplitude * kotlin.math.cos(synthesisPhase[k])
            outImag[k] = amplitude * kotlin.math.sin(synthesisPhase[k])
        }
        for (k in 1 until half) {
            outReal[size - k] = outReal[k]
            outImag[size - k] = -outImag[k]
        }
        fft(outReal, outImag, true)
        for (i in 0 until size) {
            val w = window[i]
            overlap[i] += (outReal[i] * w).toFloat()
            norm[i] += (w * w).toFloat()
        }
        for (k in 0..half) previousPhase[k] = phase[k]
        initialized = true
    }

    private fun ensureInput(required: Int) {
        if (required > input.size) input = input.copyOf(maxOf(required, input.size * 2))
    }

    private fun wrap(value: Double): Double {
        var x = value
        while (x > Math.PI) x -= 2.0 * Math.PI
        while (x < -Math.PI) x += 2.0 * Math.PI
        return x
    }

    private fun fft(real: DoubleArray, imag: DoubleArray, inverse: Boolean) {
        val n = real.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = real[i]; real[i] = real[j]; real[j] = tr
                val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val angle = 2.0 * Math.PI / len * if (inverse) 1.0 else -1.0
            val wLenR = kotlin.math.cos(angle)
            val wLenI = kotlin.math.sin(angle)
            var start = 0
            while (start < n) {
                var wr = 1.0; var wi = 0.0
                for (k in 0 until len / 2) {
                    val even = start + k
                    val odd = even + len / 2
                    val tr = wr * real[odd] - wi * imag[odd]
                    val ti = wr * imag[odd] + wi * real[odd]
                    real[odd] = real[even] - tr
                    imag[odd] = imag[even] - ti
                    real[even] += tr
                    imag[even] += ti
                    val nextWr = wr * wLenR - wi * wLenI
                    wi = wr * wLenI + wi * wLenR
                    wr = nextWr
                }
                start += len
            }
            len = len shl 1
        }
        if (inverse) for (i in 0 until n) { real[i] /= n; imag[i] /= n }
    }
}
