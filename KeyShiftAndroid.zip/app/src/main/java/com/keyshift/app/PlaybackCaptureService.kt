package com.keyshift.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioPlaybackCaptureConfiguration
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import kotlin.math.roundToInt

class PlaybackCaptureService : Service() {
    @Volatile private var shift = 0
    @Volatile private var running = false
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SET_SHIFT -> shift = intent.getIntExtra(EXTRA_SHIFT, shift).coerceIn(-12, 12)
            ACTION_STOP -> { stopCapture(); stopSelf() }
            ACTION_START -> {
                shift = intent.getIntExtra(EXTRA_SHIFT, 0).coerceIn(-12, 12)
                // Android requires the mediaProjection foreground service to be running
                // before obtaining/using the MediaProjection token.
                startCaptureForeground()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
                if (resultData == null) { stopSelf(); return START_NOT_STICKY }
                try {
                    val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = manager.getMediaProjection(resultCode, resultData)
                    beginAudioLoop()
                } catch (e: Exception) {
                    stopCapture()
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startCaptureForeground() {
        val channelId = "keyshift_capture"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(channelId, "KeyShift live capture", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("KeyShift is capturing audio")
                .setContentText("Live pitch processing is active")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("KeyShift is capturing audio")
                .setContentText("Live pitch processing is active")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(FOREGROUND_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(FOREGROUND_ID, notification)
    }

    private fun beginAudioLoop() {
        if (running) return
        running = true
        worker = Thread {
            try {
                val sampleRate = 44100
                val inputFormat = AudioFormat.Builder().setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                val captureConfig = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME).build()
                val inMin = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                recorder = AudioRecord.Builder().setAudioFormat(inputFormat)
                    .setBufferSizeInBytes(maxOf(inMin, 8192))
                    .setAudioPlaybackCaptureConfig(captureConfig).build()

                val outFormat = AudioFormat.Builder().setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                val outMin = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                track = AudioTrack.Builder().setAudioFormat(outFormat)
                    .setBufferSizeInBytes(maxOf(outMin, 8192)).setTransferMode(AudioTrack.MODE_STREAM)
                    .setAudioAttributes(android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build()).build()

                recorder?.startRecording()
                track?.play()
                val buffer = ShortArray(4096)
                while (running) {
                    val count = recorder?.read(buffer, 0, buffer.size) ?: 0
                    if (count > 0) {
                        val ratio = Math.pow(2.0, shift / 12.0)
                        val output = ShortArray(count)
                        for (i in 0 until count) {
                            output[i] = buffer[(i * ratio).roundToInt().coerceIn(0, count - 1)]
                        }
                        track?.write(output, 0, count)
                    }
                }
            } catch (_: Exception) {
                // Service may be stopped by Android or capture may be denied by source app.
            } finally { releaseAudio() }
        }.apply { name = "KeyShiftAudioCapture"; start() }
    }

    private fun stopCapture() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        releaseAudio()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun releaseAudio() {
        try { recorder?.release() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        recorder = null; track = null
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.keyshift.app.START_CAPTURE"
        const val ACTION_STOP = "com.keyshift.app.STOP_CAPTURE"
        const val ACTION_SET_SHIFT = "com.keyshift.app.SET_SHIFT"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_SHIFT = "shift"
        private const val FOREGROUND_ID = 41
    }
}
