package com.keyshift.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioPlaybackCaptureConfiguration
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Process

class PlaybackCaptureService : Service() {
    @Volatile private var shift = 0
    @Volatile private var running = false
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    @Volatile private var engineType = ENGINE_CLEAR
    @Volatile private var processor: PitchEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SET_SHIFT -> {
                shift = intent.getIntExtra(EXTRA_SHIFT, shift).coerceIn(-12, 12)
                processor?.setSemitones(shift)
            }
            ACTION_SET_ENGINE -> {
                engineType = intent.getIntExtra(EXTRA_ENGINE, engineType)
                if (running) processor = makeEngine()
            }
            ACTION_STOP -> { stopCapture(); stopSelf() }
            ACTION_START -> {
                if (running) return START_NOT_STICKY
                shift = intent.getIntExtra(EXTRA_SHIFT, 0).coerceIn(-12, 12)
                engineType = intent.getIntExtra(EXTRA_ENGINE, ENGINE_CLEAR)
                startCaptureForeground()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
                if (resultData == null) { stopSelf(); return START_NOT_STICKY }
                try {
                    val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = manager.getMediaProjection(resultCode, resultData)
                    beginAudioLoop()
                } catch (_: Exception) { stopCapture(); stopSelf() }
            }
        }
        return START_NOT_STICKY
    }

    private fun startCaptureForeground() {
        val channelId = "keyshift_capture"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(channelId, "KeyShift live capture", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId).setContentTitle("KeyShift is transposing audio")
                .setContentText("Live music processing is active").setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("KeyShift is transposing audio")
                .setContentText("Live music processing is active").setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true).build()
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(FOREGROUND_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(FOREGROUND_ID, notification)
    }

    private fun makeEngine(): PitchEngine =
        (if (engineType == ENGINE_SMOOTH) StereoPhaseVocoder(shift) else WsolaPitchShifter(shift))

    private fun beginAudioLoop() {
        running = true
        worker = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            try {
                val rate = 44100
                val inMin = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME).build()
                val inFormat = AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                // Big capture buffer: if the processing thread stalls briefly, audio is queued instead of dropped.
                recorder = AudioRecord.Builder().setAudioFormat(inFormat).setBufferSizeInBytes(maxOf(inMin * 4, 65536))
                    .setAudioPlaybackCaptureConfig(config).build()

                val outMin = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val outFormat = AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                track = AudioTrack.Builder().setAudioFormat(outFormat).setBufferSizeInBytes(maxOf(outMin * 2, 32768))
                    .setTransferMode(AudioTrack.MODE_STREAM).setAudioAttributes(
                        android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build()
                    ).build()

                val dsp = makeEngine()
                processor = dsp
                // Pre-fill ~70 ms of silence so playback never underruns (crackle) between processed blocks.
                track?.write(ShortArray(2 * 3072), 0, 2 * 3072)
                recorder?.startRecording()
                track?.play()
                val input = ShortArray(2048)
                var bypassed = false
                while (running) {
                    val n = recorder?.read(input, 0, input.size) ?: 0
                    if (n > 0) {
                        val engine = processor ?: continue
                        if (shift == 0) {
                            // No transposition: pass the audio straight through, untouched.
                            if (!bypassed) { engine.reset(); bypassed = true }
                            track?.write(input, 0, n)
                        } else {
                            bypassed = false
                            val output = engine.process(input, n)
                            if (output.isNotEmpty()) track?.write(output, 0, output.size)
                        }
                    } else if (n < 0) {
                        throw IllegalStateException("Audio capture read failed ($n)")
                    }
                }
            } catch (_: Exception) {
                // Capture can fail if the source app blocks playback capture or Android revokes permission.
            } finally { releaseAudio() }
        }.apply { name = "KeyShiftDsp"; start() }
    }

    private fun stopCapture() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        releaseAudio()
        processor = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun releaseAudio() {
        try { recorder?.release() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        recorder = null; track = null
    }

    override fun onDestroy() { stopCapture(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.keyshift.app.START_CAPTURE"
        const val ACTION_STOP = "com.keyshift.app.STOP_CAPTURE"
        const val ACTION_SET_SHIFT = "com.keyshift.app.SET_SHIFT"
        const val ACTION_SET_ENGINE = "com.keyshift.app.SET_ENGINE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_SHIFT = "shift"
        const val EXTRA_ENGINE = "engine"
        const val ENGINE_CLEAR = 0   // WSOLA time-domain shifter (default, best for vocals)
        const val ENGINE_SMOOTH = 1  // original phase vocoder
        private const val FOREGROUND_ID = 41
    }
}
